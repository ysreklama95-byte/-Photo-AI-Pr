import base64
import os
import uuid
from pathlib import Path

import requests
from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.staticfiles import StaticFiles

app = FastAPI(title="Photo AI Pro API")
OUTPUT_DIR = Path("outputs")
OUTPUT_DIR.mkdir(exist_ok=True)
app.mount("/outputs", StaticFiles(directory=str(OUTPUT_DIR)), name="outputs")

STABILITY_URL = "https://api.stability.ai/v1/generation/esrgan-v1-x2plus/image-to-image/upscale"

@app.get("/health")
def health():
    return {"status": "ok", "service": "Photo AI Pro"}

@app.post("/enhance")
async def enhance(file: UploadFile = File(...)):
    api_key = os.getenv("STABILITY_API_KEY")
    if not api_key:
        raise HTTPException(status_code=503, detail="Serverda STABILITY_API_KEY sozlanmagan")

    allowed = {"image/jpeg", "image/png", "image/webp"}
    if file.content_type not in allowed:
        raise HTTPException(status_code=415, detail="Faqat JPG, PNG yoki WebP rasmlar qabul qilinadi")

    data = await file.read()
    if not data or len(data) > 15 * 1024 * 1024:
        raise HTTPException(status_code=413, detail="Rasm bo‘sh yoki 15 MB dan katta")

    try:
        response = requests.post(
            STABILITY_URL,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Accept": "application/json",
            },
            files={"image": (file.filename or "photo.jpg", data, file.content_type)},
            timeout=150,
        )
    except requests.RequestException as exc:
        raise HTTPException(status_code=502, detail=f"AI serveriga ulanib bo‘lmadi: {exc}")

    if response.status_code != 200:
        raise HTTPException(status_code=502, detail=f"AI xizmati xatosi ({response.status_code}): {response.text[:500]}")

    try:
        payload = response.json()
        encoded = payload["artifacts"][0]["base64"]
        image_bytes = base64.b64decode(encoded)
    except Exception:
        raise HTTPException(status_code=502, detail="AI javobini o‘qib bo‘lmadi")

    filename = f"{uuid.uuid4().hex}.png"
    (OUTPUT_DIR / filename).write_bytes(image_bytes)

    # Set PUBLIC_BASE_URL to your HTTPS backend origin in production.
    base_url = os.getenv("PUBLIC_BASE_URL", "http://localhost:8000").rstrip("/")
    return {"image_url": f"{base_url}/outputs/{filename}", "filename": filename}
