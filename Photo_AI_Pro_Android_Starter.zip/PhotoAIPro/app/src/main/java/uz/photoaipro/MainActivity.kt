package uz.photoaipro

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PhotoAIProScreen() }
    }
}

@Composable
fun PhotoAIProScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var resultUrl by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Suratingizni tanlang va AI yordamida yaxshilang.") }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        selectedUri = uri
        resultUrl = null
        message = if (uri != null) "Rasm tanlandi. Endi AI bilan yaxshilang." else "Rasm tanlanmadi."
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF9B8CFF),
            secondary = Color(0xFF55D6BE),
            background = Color(0xFF0B1020),
            surface = Color(0xFF171D31)
        )
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color(0xFF171B36), Color(0xFF080C18))))
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(22.dp))
            Icon(Icons.Default.AutoAwesome, null, tint = Color(0xFFB7A9FF), modifier = Modifier.size(42.dp))
            Text("Photo AI Pro", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = Color.White)
            Text("Suratlaringizga yangi hayot bering", color = Color(0xFFB8BED2))
            Spacer(Modifier.height(24.dp))

            Card(
                modifier = Modifier.fillMaxWidth().weight(1f),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF171D31))
            ) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    when {
                        resultUrl != null -> AsyncImage(resultUrl, contentDescription = "Yaxshilangan rasm", modifier = Modifier.fillMaxSize())
                        selectedUri != null -> AsyncImage(selectedUri, contentDescription = "Tanlangan rasm", modifier = Modifier.fillMaxSize())
                        else -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.PhotoLibrary, null, tint = Color(0xFF9B8CFF), modifier = Modifier.size(64.dp))
                            Text("Rasm hali tanlanmagan", color = Color.White)
                        }
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
            Text(message, color = Color(0xFFD5D9E8))
            Spacer(Modifier.height(12.dp))
            OutlinedButton(
                onClick = { picker.launch("image/*") },
                modifier = Modifier.fillMaxWidth().height(54.dp)
            ) { Text("Galereyadan rasm tanlash") }
            Spacer(Modifier.height(10.dp))
            Button(
                onClick = {
                    val uri = selectedUri ?: return@Button
                    busy = true
                    message = "AI rasmni qayta ishlayapti..."
                    scope.launch {
                        try {
                            val url = enhanceImage(context, uri)
                            resultUrl = url
                            message = "Tayyor! Yaxshilangan rasm quyida."
                        } catch (e: Exception) {
                            message = "Xatolik: ${e.message ?: "Server bilan bog‘lanib bo‘lmadi"}"
                        } finally { busy = false }
                    }
                },
                enabled = selectedUri != null && !busy,
                modifier = Modifier.fillMaxWidth().height(56.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                if (busy) CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
                else {
                    Icon(Icons.Default.AutoAwesome, null)
                    Spacer(Modifier.width(8.dp))
                    Text("AI bilan sifatini oshirish")
                }
            }
            Spacer(Modifier.height(10.dp))
            Text("Internet talab qilinadi • AI qayta ishlashi pullik bo‘lishi mumkin", color = Color(0xFF929AB2), style = MaterialTheme.typography.bodySmall)
        }
    }
}

private suspend fun enhanceImage(context: android.content.Context, uri: Uri): String =
    withContext(Dispatchers.IO) {
        val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            ?: error("Rasm faylini o‘qib bo‘lmadi")
        require(bytes.size <= 15 * 1024 * 1024) { "Rasm hajmi 15 MB dan kichik bo‘lishi kerak" }

        val client = OkHttpClient.Builder()
            .callTimeout(180, TimeUnit.SECONDS)
            .build()
        val body = MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("file", "photo.jpg", bytes.toRequestBody("image/jpeg".toMediaType()))
            .build()
        val request = Request.Builder()
            .url(BuildConfig.BASE_URL + "enhance")
            .post(body)
            .build()
        client.newCall(request).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) error("Server ${response.code}: $text")
            val json = JSONObject(text)
            json.getString("image_url")
        }
    }
